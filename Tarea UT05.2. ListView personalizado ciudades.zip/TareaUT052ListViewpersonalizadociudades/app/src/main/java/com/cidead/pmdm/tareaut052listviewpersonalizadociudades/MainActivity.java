package com.cidead.pmdm.tareaut052listviewpersonalizadociudades;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
// Diego Manuel Carrasco Castañares
public class MainActivity extends AppCompatActivity {
    private ListView lv;
    private Adaptador adaptador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ArrayList<ModeloCiudad> ciudades = new ArrayList<ModeloCiudad>();
        ModeloCiudad m1 = new ModeloCiudad();
        m1.setCodigo(1);
        m1.setNombre("Mérida");
        m1.setComunidad("Extremadura");
        m1.setFoto(R.drawable.ic_merida);
        m1.setMonumento("Teatro romano de Mérida");
        ModeloCiudad m2 = new ModeloCiudad();
        m2.setCodigo(2);
        m2.setNombre("Avila");
        m2.setComunidad("Castilla y Leon");
        m2.setFoto(R.drawable.ic_avila);
        m2.setMonumento("Muralla de Avila");
        ModeloCiudad m3 = new ModeloCiudad();
        m3.setCodigo(3);
        m3.setNombre("Segovia");
        m3.setComunidad("Castilla y Leon");
        m3.setFoto(R.drawable.ic_segovia);
        m3.setMonumento("Acueducto de Segovia");
        ModeloCiudad m4 = new ModeloCiudad();
        m4.setCodigo(4);
        m4.setNombre("Granada");
        m4.setComunidad("Andalucia");
        m4.setFoto(R.drawable.ic_granada);
        m4.setMonumento("La Alhambra de Granada");
        ModeloCiudad m5 = new ModeloCiudad();
        m5.setCodigo(5);
        m5.setNombre("Sevilla");
        m5.setComunidad("Andalucia");
        m5.setFoto(R.drawable.ic_sevilla);
        m5.setMonumento("El Real Alcazar de Sevilla");

        ciudades.add(m1);
        ciudades.add(m2);
        ciudades.add(m3);
        ciudades.add(m4);
        ciudades.add(m5);

        adaptador = new Adaptador(this, ciudades);

        lv = (ListView) findViewById(R.id.lv);
        lv.setAdapter(adaptador);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adaptpaerView, View view, int i, long l) {

                try {
                    ModeloCiudad ciudad = (ModeloCiudad) adaptador.getItem(i);
                    Log.e("Ciudad", ciudad.getCodigo()+" - "+ciudad.getNombre()+". perteneciente a la " +
                            "comunidad de "+ciudad.getComunidad());
                    Toast.makeText(getBaseContext(), "El monumento mas significativo de "+ciudad.getNombre()+
                            " es "+ciudad.getMonumento(), Toast.LENGTH_LONG).show();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
    }
}