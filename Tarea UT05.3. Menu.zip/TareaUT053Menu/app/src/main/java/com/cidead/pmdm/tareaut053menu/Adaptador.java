package com.cidead.pmdm.tareaut053menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
// Diego Manuel Carrasco Castañares
public class Adaptador extends BaseAdapter {
    private Context miContexto;
    private ArrayList <ModeloCiudad> miArrayList;

    public Adaptador(Context miContexto, ArrayList<ModeloCiudad> miArrayList) {
        this.miContexto = miContexto;
        this.miArrayList = miArrayList;
    }

    @Override
    public int getCount() {
        return miArrayList.size();
    }

    @Override
    public Object getItem(int i) {
        return miArrayList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return miArrayList.get(i).getCodigo();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater layoutInflater=LayoutInflater.from(miContexto);
        view=layoutInflater.inflate(R.layout.item, null);
        TextView nombre=(TextView) view.findViewById(R.id.tvNombre);
        TextView comunidad=(TextView) view.findViewById(R.id.tvComunidad);
        ImageView foto=(ImageView) view.findViewById(R.id.imgCiudad);
        nombre.setText(miArrayList.get(i).getNombre());
        comunidad.setText(miArrayList.get(i).getComunidad());
        foto.setImageResource(miArrayList.get(i).getFoto());
        return view;
    }
}
