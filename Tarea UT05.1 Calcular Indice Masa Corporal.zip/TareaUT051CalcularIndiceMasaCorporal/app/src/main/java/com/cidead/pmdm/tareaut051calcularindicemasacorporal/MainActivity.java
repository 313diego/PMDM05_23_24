package com.cidead.pmdm.tareaut051calcularindicemasacorporal;

import androidx.appcompat.app.AppCompatActivity;
import android.content.pm.ActivityInfo;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

// Diego Manuel Carrasco Castañares
public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnCalcularImc;
    EditText etNombre;
    EditText etAltura;
    EditText etPeso;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
        setContentView(R.layout.activity_main);
        btnCalcularImc=(Button)findViewById(R.id.btCalcular);
        btnCalcularImc.setOnClickListener(this);
        etNombre=(EditText) findViewById(R.id.etNombre);
        etAltura=(EditText) findViewById(R.id.etAltura);
        etPeso=(EditText) findViewById(R.id.etPeso);
    }

    @Override
    public void onClick(View v) {
        Intent i=new Intent(getApplicationContext(), SegundaActivity.class);
        i.putExtra("nombre",etNombre.getText().toString());
        i.putExtra("altura", etAltura.getText().toString());
        i.putExtra("peso", etPeso.getText().toString());
        startActivity(i);
    }
}