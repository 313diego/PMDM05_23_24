package com.cidead.pmdm.tareaut051calcularindicemasacorporal;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

// Diego Manuel Carrasco Castañares
public class SegundaActivity extends AppCompatActivity {

    Button btnVolver;
    TextView tvNombre2;
    TextView tvAltura2;
    TextView tvPeso2;
    TextView tvImc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
        setContentView(R.layout.activity_segunda);
        btnVolver=(Button)findViewById(R.id.btVolver);
        tvNombre2=(TextView) findViewById(R.id.etNombre2);
        tvAltura2=(TextView) findViewById(R.id.etAltura2);
        tvPeso2=(TextView) findViewById(R.id.etPeso2);
        tvImc=(TextView) findViewById(R.id.etImc);
        btnVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Para salir completamente de la app finishAffinity(), para salir de la actividad finish()
                finish();
            }
        });

        Intent i = getIntent();
        String nombre = i.getStringExtra("nombre");
        String altura = i.getStringExtra("altura");
        String peso = i.getStringExtra("peso");
        String tipoImc=null;
        double alt=Double.parseDouble(altura)/100;
        double kg=Double.parseDouble(peso);
        double IMC=0;
        IMC = kg /(alt*alt);
        if (IMC >= 18.5 && IMC <= 24.99){
            tipoImc = "normal";
        } else if (IMC >= 25 && IMC <= 29.99) {
            tipoImc = "sobrepeso";
        } else if (IMC >= 30 && IMC <= 34.99) {
            tipoImc = "Obesidad grado I";
        } else if (IMC >= 35 && IMC <= 39.99) {
            tipoImc = "Obesidad grado II";
        } else if (IMC > 40) {
            tipoImc = "Obesidad grado III";
        }
        String datoIMC = String.format("%.2f",IMC);
        tvNombre2.setText(new StringBuilder().append(nombre).append(getString(R.string.tu_imc_indica)).append(tipoImc).toString());
        tvAltura2.setText(new StringBuilder().append("Altura: ").append(altura).toString());
        tvPeso2.setText(new StringBuilder().append("Peso: ").append(peso).toString());
        tvImc.setText(new StringBuilder().append("Tu IMC es de: ").append(datoIMC).toString());
    }
}